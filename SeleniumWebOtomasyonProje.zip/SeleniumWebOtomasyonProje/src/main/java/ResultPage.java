import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Random;

public class ResultPage {

    public ResultPage(WebDriver webDriver) {
        super(WebDriver);
    }

    public By randomSelectProductBy() {
        Random random = new Random();
        int rand = random.nextInt(48) + 1;
        return By.cssSelector(".products-container>li:nth-of-type(" + rand + ")");
    }

    public void choosePage(String pageNumber) {
        WebDriver.get(WebDriver.getCurrentUrl() + "&sf=" + pageNumber);
    }


    }




