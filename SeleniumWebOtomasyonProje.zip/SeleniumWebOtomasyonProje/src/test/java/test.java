import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class test {
     @Test
     public void testcase() {
         System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\IdeaProjects\\SeleniumWebOtomasyonProje\\driver\\chromedriver.exe");
         WebDriver driver=new ChromeDriver(); driver.manage().window().maximize();
         driver.get("https://www.gittigidiyor.com");


         driver.manage().window().maximize();
         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         driver.get("https://www.gittigidiyor.com/uye-girisi");

         WebElement username=driver.findElement(By.id("L-UserNameField"));
         WebElement password=driver.findElement(By.id("L-PasswordField"));
         WebElement login=driver.findElement(By.id("gg-login-enter"));
         username.sendKeys("example@gmail.com"); password.sendKeys("password");
         login.click(); String actualUrl="https://www.gittigidiyor.com/";
         String expectedUrl= driver.getCurrentUrl();
         Assert.assertEquals(expectedUrl,actualUrl);


         WebElement searchBox = WebDriver.findElement(By.className("sc-4995aq-0"));
         searchBox.click();
         WebElement fillsearchBox = WebDriver.findElement(By.className("sc-4995aq-0"));
         fillsearchBox.sendKeys("bilgisayar");

         ResultPage searchResultPage = homePage.search("bilgisayar");
         ResultPage.scrollToPage("7200");
         ResultPage.choosePage("2");





     }


}


